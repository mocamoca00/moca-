<?php include "head.php"; ?>
<?php include "list.php"; ?>
<?php include "foot.php"; ?>