-- v1.6.0
INSERT INTO `lylme_config` VALUES ('wxplus', '','微信推送密钥');
INSERT INTO `lylme_config` VALUES ('wxplustime', '20:00','微信推送时间');